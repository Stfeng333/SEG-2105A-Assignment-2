// ------------------------------------------------------------------------------
// Assignment #2
// Written by: Steven Feng Peng (300313545)
// For SEG2105[A]
// Time needed to complete this assignment: 3 hours and 52 mins
// List the resources used to complete this assignment: class notes, assignment instructions, ITI 1121 samples, geek for geeks, stack overflow, youtube, 
// ----------------------------------------------------------------------------- 

package edu.seg2105.client.backend;

import ocsf.client.*;

import java.io.*;

import edu.seg2105.client.common.*;

public class ChatClient extends AbstractClient {
  //add variable for the login id
  private String loginId;
  ChatIF clientUI;

  public ChatClient(String loginId, String host, int port, ChatIF clientUI)
      throws IOException {
    // Call the superclass constructor
    super(host, port);
    if (loginId == null || loginId.isEmpty()) {
      throw new IllegalArgumentException("Login ID must be provided.");
    }
    this.loginId = loginId;
    this.clientUI = clientUI;
    openConnection();
  }

  public void handleMessageFromServer(Object msg) {
    clientUI.display(msg.toString());
  }

  public void quit() {
    try {
      closeConnection();
    } catch (IOException e) {
    }
    System.exit(0);
  }

  // Override connectionClosed method to display message to the client when the connection is closed.
  @Override
  protected void connectionClosed() {
    clientUI.display("Connection closed.");
  }

  // Override connectionException method to display message to the client when the connection is closed.
  @Override
  protected void connectionException(Exception exception) {
    clientUI.display("Connection exception: " + exception.getMessage());
    quit();
  }

  // Override connectionEstablished method to display message to the client when the connection is established.
  @Override
  protected void connectionEstablished() {
    clientUI.display("Connection established.");
    try {
      //when a client connects to a server, it should automatically send the message ‘#login <loginid>’ to the server
      sendToServer("#login " + loginId);
    } catch (IOException e) {
      clientUI.display("Error sending login ID to server.");
      quit();
    }
  }

  // method handleMessageFromClientUI is used to handle the messages that are sent by the client.
  public void handleMessageFromClientUI(String message) {
    if (message.startsWith("#")) {
      handleCommand(message);
    } else {
      try {
        sendToServer(message);
      } catch (IOException e) {
        clientUI.display("Could not send message to server. Terminating client.");
        quit();
      }
    }
  }

  // method handleCommand is used to handle the commands that are sent by the client.
  private void handleCommand(String message) {
    String[] tokens = message.split(" ");
    String command = tokens[0];

    switch (command) {
      // #quit causes the client to quit gracefully.
      case "#quit":
        quit();
        break;
      // #logoff closes the connection to the server
      case "#logoff":
        try {
          closeConnection();
        } catch (IOException e) {
          clientUI.display("Error logging off.");
        }
        break;
      // #sethost is used to display message to the client if the client is connected or if the host name is invalid.
      case "#sethost":
        if (isConnected()) {
          clientUI.display("Cannot set host while connected.");
        } else if (tokens.length > 1) {
          setHost(tokens[1]);
        } else {
          clientUI.display("Host not specified.");
        }
        break;
      // #setport is used to display message to the client if the client is connected or if the port number is invalid.
      case "#setport":
        if (isConnected()) {
          clientUI.display("Cannot set port while connected.");
        } else if (tokens.length > 1) {
          try {
            setPort(Integer.parseInt(tokens[1]));
          } catch (NumberFormatException e) {
            clientUI.display("Invalid port number.");
          }
        } else {
          clientUI.display("Port not specified.");
        }
        break;
      // #login attempts to establish a connection to the server.
      case "#login":
        if (isConnected()) {
          clientUI.display("Already connected.");
        } else {
          try {
            openConnection();
          } catch (IOException e) {
            clientUI.display("Error logging in.");
          }
        }
        break;
      // #gethost displays the current host name.
      case "#gethost":
        clientUI.display("Current host: " + getHost());
        break;
      // #getport displays the current port number.
      case "#getport":
        clientUI.display("Current port: " + getPort());
        break;
      default:
        clientUI.display("Unknown command.");
        break;
    }
  }

  // Getter for loginId
  public String getLoginId() {
    return loginId;
  }
}
