// ------------------------------------------------------------------------------
// Assignment #2
// Written by: Steven Feng Peng (300313545)
// For SEG2105[A]
// Time needed to complete this assignment: 3 hours and 52 mins
// List the resources used to complete this assignment: class notes, assignment instructions, ITI 1121 samples, geek for geeks, stack overflow, youtube, 
// ----------------------------------------------------------------------------- 
package edu.seg2105.client.ui;

import java.io.IOException;
import java.util.Scanner;

import edu.seg2105.client.common.ChatIF;

//new class Server console
//Anything typed on the server’s console by an end-user of the server should be echoed to the server’s console and to all the clients
public class ServerConsole implements ChatIF {
    final public static int DEFAULT_PORT = 5555;
    ChatServer server;

    Scanner fromConsole;

    //constructor
    public ServerConsole(int port) {
        try {
            server = new ChatServer(port, this);
            server.listen(); // Start listening for connections
        } catch (IOException exception) {
            System.out.println("Error: Can't setup connection! Terminating server.");
            System.exit(1);
        }

        // Create scanner object to read from console
        fromConsole = new Scanner(System.in);
    }

    public void display(String message) {
        System.out.println("> " + message);
    }

    
    public static void main(String[] args) {
        // Port to listen on
        int port = 0; 

        try {
            // Get port from command line
            port = Integer.parseInt(args[0]); 
        } catch (Throwable t) {
            // Set port to 5555
            port = DEFAULT_PORT; 
        }

        ServerConsole server = new ServerConsole(port);
        // Wait for console data
        server.accept(); 
    }


    private void processCommand(String command) {
        if (command.startsWith("#")) {
            switch (command) {
                //#quit causes the server to quit gracefully.
                case "#quit":
                    server.close();
                    System.exit(0);
                    break;
                //#stop causes the server to stop listening for new clients
                case "#stop":
                    server.stopListening();
                    break;
                //#close causes the server not only to stop listening for new clients, but also to disconnect all existing clients
                case "#close":
                    server.close();
                    break;
                //#start causes the server to start listening for new clients. Only valid if the server is stopped.
                case "#start":
                    try {
                        server.listen();
                    } catch (IOException e) {
                        System.out.println("Error: Could not start listening for clients.");
                    }
                    break;
                //#getport displays the current port number.
                case "#getport":
                    System.out.println("Current port: " + server.getPort());
                    break;
                default:
                //#setport <port> calls the setPort method in the server, but only if the server is closed
                    if (command.startsWith("#setport")) {
                        String[] tokens = command.split(" ");
                        if (tokens.length == 2) {
                            try {
                                int port = Integer.parseInt(tokens[1]);
                                server.setPort(port);
                                System.out.println("Port set to: " + port);
                            } catch (NumberFormatException e) {
                                System.out.println("Invalid port number.");
                            }
                        } else {
                            System.out.println("Usage: #setport <port>");
                        }
                    } else {
                        System.out.println("Unknown command.");
                    }
                    break;
            }
        } else {
            //Any message originating from the end-user of the server should be prefixed by the string "SERVER MSG>"
            server.sendToAllClients("SERVER MSG> " + command);
            display("SERVER MSG> " + command);
        }
    }

    //override accept method to process commands on message
    @Override
    public void accept() {
        try {
            String message;

            while (true) {
                message = fromConsole.nextLine();
                processCommand(message);
            }
        } catch (Exception ex) {
            System.out.println("Unexpected error while reading from console!");
        }
    }
}