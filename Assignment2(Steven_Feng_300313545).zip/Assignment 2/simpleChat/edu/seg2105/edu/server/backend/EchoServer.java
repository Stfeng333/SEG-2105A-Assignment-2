// ------------------------------------------------------------------------------
// Assignment #2
// Written by: Steven Feng Peng (300313545)
// For SEG2105[A]
// Time needed to complete this assignment: 3 hours and 52 mins
// List the resources used to complete this assignment: class notes, assignment instructions, ITI 1121 samples, geek for geeks, stack overflow, youtube, 
// ----------------------------------------------------------------------------- 

package edu.seg2105.edu.server.backend;
// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

import ocsf.server.*;

/**
 * This class overrides some of the methods in the abstract 
 * superclass in order to give more functionality to the server.
 *
 * @autho Dr Timothy C. Lethbridge
 * @autho Dr Robert Lagani&egrave;re
 * @autho Fran&ccedil;ois B&eacute;langer
 * @autho Paul Holden
 */
public class EchoServer extends AbstractServer 
{
  //Class variables *************************************************
  
  /**
   * The default port to listen on.
   */
  final public static int DEFAULT_PORT = 5555;
  
  //Constructors ****************************************************
  
  /**
   * Constructs an instance of the echo server.
   *
   * @param port The port number to connect on.
   */
  public EchoServer(int port) 
  {
    super(port);
  }

  
  //Instance methods ************************************************
  
  /**
   * This method handles any messages received from the client.
   *
   * @param msg The message received from the client.
   * @param client The connection from which the message originated.
   */
  //modify handleMessageFromClient method to handle messages from the client
  public void handleMessageFromClient(Object msg, ConnectionToClient client)
  {
    String message = msg.toString();
    //if the message starts with #login, the server should store the login id in the client’s information
    if (message.startsWith("#login ")) {
      String loginId = message.substring(7).trim();
      if (client.getInfo("loginId") == null) {
        client.setInfo("loginId", loginId);
        System.out.println("Client " + loginId + " has logged in.");
      } else {
        try {
          client.sendToClient("ERROR - You are already logged in.");
          client.close();
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
    } else {
      String loginId = (String) client.getInfo("loginId");
      if (loginId == null) {
        try {
          client.sendToClient("ERROR - You need to login first.");
          client.close();
        } catch (Exception e) {
          e.printStackTrace();
        }
      } else {
        // Display message received
        System.out.println("Message received: " + message + " from " + loginId);
        this.sendToAllClients(loginId + ": " + message);
      }
    }
  }
    
  /**
   * Method that overrides the one in the superclass.  Called
   * when the server starts listening for connections.
   */
  protected void serverStarted()
  {
    System.out.println("Server listening for connections on port " + getPort());
  }
  
  /**
   * Method that overrides the one in the superclass.  Called when the server stops listening for connections.
   */
  protected void serverStopped()
  {
    System.out.println("Server has stopped listening for connections.");
  }
  
  
  //Class methods ***************************************************
  
  /**
   * This method is responsible for the creation of 
   * the server instance (there is no UI in this phase).
   *
   * @param args[0] The port number to listen on.  Defaults to 5555 
   *          if no argument is entered.
   */

   //main method implementation
  public static void main(String[] args) 
  {
    //Port to listen on
    int port = 0; 

    try
    {
      //Get port from command line
      port = Integer.parseInt(args[0]); 
    }
    catch(Throwable t)
    {
      //Set port to 5555
      port = DEFAULT_PORT; 
    }
  
    //Create a server object and start it
    EchoServer sv = new EchoServer(port);
    
    try 
    {
      //Start listening for connections
      sv.listen(); 
    } 
    catch (Exception ex) 
    {
      System.out.println("ERROR - Could not listen for clients!");
    }
  }
}
//End of EchoServer class
