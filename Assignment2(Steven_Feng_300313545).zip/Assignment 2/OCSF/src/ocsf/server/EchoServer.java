// ------------------------------------------------------------------------------
// Assignment #2
// Written by: Steven Feng Peng (300313545)
// For SEG2105[A]
// Time needed to complete this assignment: 3 hours and 52 mins
// List the resources used to complete this assignment: class notes, assignment instructions, ITI 1121 samples, geek for geeks, stack overflow, youtube, 
// ----------------------------------------------------------------------------- 

package ocsf.server;
import java.io.IOException;
//created class EchoServer that extends AbstractServer, to override the necessary methods
public class EchoServer extends AbstractServer {

	public EchoServer(int port) {
		super(port);
	}

    //override clientConnected method to display message to the server when a client connects
	@Override
	protected void clientConnected(ConnectionToClient client) {
		System.out.println("Client connected: " + client);
	}

    //override clientDisconnected method to display message to the server when a client disconnects
	@Override
	synchronized protected void clientDisconnected(ConnectionToClient client) {
		System.out.println("Client disconnected: " + client);
	}

    //override clientException method to display message to the server when a client throws an exception
	@Override
	synchronized protected void clientException(ConnectionToClient client, Throwable exception) {
		System.out.println("Client exception: " + client + " - " + exception);
	}

    //override handleMessageFromClient method to display message to the server when a message is received from a client
	@Override
	protected void handleMessageFromClient(Object msg, ConnectionToClient client) {
		// Handle the message from the client
        System.out.println("Message from client: " + msg + " - " + client);
        try {
            client.sendToClient(msg);
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
	}
}
// End of AbstractServer Class
